"""import pandas as pd
import matplotlib.pyplot as plt
datos = pd.read_csv('D://usuarios//pablo//Downloads//players_fifa22.csv')
df = datos[["ID","Name","Age","Overall", "Potential", "Club", "ValueEUR"]]

df.Potential.plot.hist()
plt.show()

valor_club = df.groupby("Club")["Age"].mean()
valor_club.head(20).plot.barh()
plt.show()"""

import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

datos = pd.read_csv('D://usuarios//pablo//Downloads//players_fifa22.csv') #Leemos el Archivo
df = datos[["ID","Name","Age","Overall", "Potential", "Club", "ValueEUR"]] #Añadimos las columnas

#Asignamos a las variables los datos, y solo se mostraran los 5 Primeros
x = datos["Age"].head(5)
y = datos["Overall"].head(5)
z = datos["ValueEUR"].head(5)

figura = plt.figure() #Creamos la Gráfica
ax=figura.add_subplot(111, projection="3d") #Add_subplot su funcion es subdividir la figura
ax.scatter3D(x, y, z, c=z, cmap="Set1")#Tiene que ver con la dispersion(Diagrama de Puntos)
#Set1 tiene que ver con los colores de los elementos
plt.show()
